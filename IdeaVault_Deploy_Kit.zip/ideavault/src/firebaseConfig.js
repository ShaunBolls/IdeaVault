export const firebaseConfig = {
  apiKey: "AIzaSyChqGj7zXq0ap2F5Mdihh1oR98160jCCe8",
  authDomain: "ideavault-e7ec2.firebaseapp.com",
  projectId: "ideavault-e7ec2",
  storageBucket: "ideavault-e7ec2.firebasestorage.app",
  messagingSenderId: "790370063420",
  appId: "1:790370063420:web:5f3e4dc6f31d6e8d869f39",
  measurementId: "G-ZV4NVDK792"
};