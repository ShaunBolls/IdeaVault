IDEAVAULT DEPLOYMENT GUIDE

1. Unzip this folder
2. Open terminal or CMD in the 'ideavault' folder
3. Run: npm install -g firebase-tools
4. Run: firebase login
5. Then run the script:
   setup\deploy.bat

Your app will be deployed to Firebase Hosting.
