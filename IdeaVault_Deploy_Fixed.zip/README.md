# IdeaVault

A secure platform to share, protect, and monetize your ideas.

## Deployment Instructions

1. Push this project to a GitHub repository (e.g., `ShaunBolls/IdeaVault`).
2. Go to [Vercel](https://vercel.com/new) and import the GitHub repo.
3. Use the following settings during Vercel setup:
   - Framework: **Other**
   - Root Directory: **/** (leave blank or `/`)
   - Output Directory: **public** or leave blank if not applicable
4. Your site should now deploy without a 404 error.

Make sure the `vercel.json` file is included in the root to rewrite all paths to `index.html`.
